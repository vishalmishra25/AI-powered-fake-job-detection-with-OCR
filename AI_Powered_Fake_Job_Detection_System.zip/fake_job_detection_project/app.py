from pathlib import Path
import pickle
import re
from flask import Flask, render_template, request, jsonify

BASE_DIR = Path(__file__).resolve().parent
MODEL_PATH = BASE_DIR / "models" / "fake_job_model.pkl"

app = Flask(__name__)


def ensure_model():
    """Train a baseline model on the bundled demo dataset if none exists."""
    if not MODEL_PATH.exists():
        from train_model import train_model
        train_model()


def get_warning_signals(text, company, salary, website):
    combined = f"{text} {company} {salary} {website}".lower()
    checks = [
        (r"\b(registration fee|pay.*fee|upfront payment|security deposit|training fee)\b", "Requests an upfront fee or payment"),
        (r"\b(otp|one.time password|password|pin|bank details)\b", "Mentions sensitive credentials or financial details"),
        (r"\b(guaranteed job|no interview|earn .*daily|easy money|instant hiring)\b", "Uses unusually strong or unrealistic promises"),
        (r"\b(act now|urgent|immediately|limited time|today only)\b", "Uses pressure or urgency language"),
        (r"\b(whatsapp only|telegram only|message on telegram)\b", "Pushes communication to an informal channel"),
        (r"\b(no experience required.*high salary|work from home.*\$?\d{3,})\b", "Pairs minimal requirements with unusually high pay"),
    ]
    signals = [label for pattern, label in checks if re.search(pattern, combined)]
    if not company.strip():
        signals.append("Company name was not provided")
    if not website.strip():
        signals.append("Company website was not provided")
    return signals


@app.route("/", methods=["GET", "POST"])
def index():
    result = None
    form = {"job_title": "", "company": "", "salary": "", "website": "", "description": ""}
    if request.method == "POST":
        form = {key: request.form.get(key, "").strip() for key in form}
        text = " ".join([form["job_title"], form["company"], form["salary"], form["website"], form["description"]])
        if len(form["description"]) < 15 and not form["job_title"]:
            result = {"error": "Please enter a job title or a job description (at least 15 characters)."}
        else:
            ensure_model()
            with open(MODEL_PATH, "rb") as f:
                model = pickle.load(f)
            prediction = int(model.predict([text])[0])
            probabilities = model.predict_proba([text])[0]
            classes = list(model.classes_)
            fake_index = classes.index(1) if 1 in classes else 1
            risk = round(float(probabilities[fake_index]) * 100)
            signals = get_warning_signals(text, form["company"], form["salary"], form["website"])
            # Add context-based caution without pretending the rules are model explanations.
            if signals:
                risk = min(99, max(risk, min(95, 45 + 9 * len(signals))))
            label = "Potentially Suspicious" if prediction == 1 or risk >= 55 else "Lower Risk Indicators"
            result = {
                "label": label,
                "risk": risk,
                "signals": signals or ["No obvious warning phrase was matched by the basic checks."],
                "advice": ("Do not pay fees or share OTPs/passwords. Verify the employer using independently found official contact details." if label == "Potentially Suspicious" else "Still verify the company, job listing, and recruiter through official channels before sharing personal information."),
                "model_note": "Baseline TF-IDF + Logistic Regression model trained on a small bundled demonstration dataset. This result is not proof that a job is genuine or fraudulent."
            }
    return render_template("index.html", result=result, form=form)


@app.route("/health")
def health():
    return jsonify({"status": "ok", "project": "AI-Powered Fake Job Detection System"})


if __name__ == "__main__":
    ensure_model()
    app.run(debug=True)
